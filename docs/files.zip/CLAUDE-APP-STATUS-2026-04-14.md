# Grey Sky Portal — Status Update for Claude App
**Date:** April 14, 2026
**Source:** Architecture Agent (Claude App)

---

## Current State Summary

**48 commits | 136 TS/TSX files | 15,180 lines of code | 9 SQL migrations | 17 design docs**

The portal has a complete public marketing site, full authentication system, member dashboard shell, member profiles with deployment records, and an incident registry. Database schema is deployed with 24 tables, 30 enums, and RLS on every table.

---

## What's Built (Complete)

### Phase 0 — Foundation (ALL COMPLETE)
| Doc | What shipped |
|-----|-------------|
| DOC-000 | Platform Reference Spec (canonical) |
| DOC-001 | Backend Foundation — entity map, TypeScript models |
| DOC-002 | Database Schema — 24 tables, 30 enums, 8 migration files, RLS everywhere |
| DOC-003 | Seed Data — 468 RTLT positions, 152 team types, 37 affinities (deterministic UUIDs) |
| DOC-004 | Project Scaffolding — Next.js 16 + Supabase + Docker Compose |
| DOC-005 | Environment Config — typed env validation, storage + email abstraction |
| DOC-006 | CI/CD — GitHub Actions: lint, type-check, build, Azure SWA deploy |

### Phase 1 — Public Site (SUBSTANTIALLY COMPLETE)
| Doc | What shipped |
|-----|-------------|
| DOC-005-PUBLIC | Full public site: Homepage, /about, /story, /community, /membership, /teams (20), /positions (468, paginated), /standards (17), /join funnel |

**NOT yet built in Phase 1:**
- DOC-101: Membership page copy — Sky Coins details now resolved (OD-03 closed)
- DOC-102: Organizations/Agencies page — APPROVED, included in Concurrent Build Round 2
- DOC-105: Contact page — mailto only in footer

### Phase 2 — Member Portal (IN PROGRESS)
| Doc | What shipped |
|-----|-------------|
| DOC-200 | Auth — Supabase Auth (GoTrue), register, login, password reset, email verification, middleware role enforcement, MFA placeholder deferred to DOC-900 |
| DOC-201 | Dashboard Layout — sidebar (desktop) + bottom nav (mobile), 13 components |
| DOC-202 | Member Profile — basic view/edit built. Expanded spec committed (service history, qualifications, languages, completeness engine — NOT yet built) |
| DOC-203 | Deployment Records — full CRUD, RTLT position search, inline incident creation, draft→submitted workflow |
| DOC-204 | Incident Registry — ICS 209 alignment, FEMA enrichment fields, geospatial support, search/filter, timeline, dashboard + public pages |

---

## Concurrent Build Round 2 — IN QUEUE

Five approved docs, all unblocked, ready for parallel Claude Code execution:

| # | Doc | Title | Priority |
|---|-----|-------|----------|
| 1 | DOC-202 Expansion | Profile — service history, qualifications, languages, completeness engine | critical |
| 2 | DOC-205 | Sky Coins Economy — balance, ledger, product catalog, dashboard UI | high |
| 3 | DOC-206 | Document Library — upload, categorize, link, avatar | high |
| 4 | DOC-102 | Organizations + Agencies public page | high |
| 5 | DOC-900 | Security Hardening — MFA, CSP, CORS, rate limiting, audit hash chain | critical |

Self-contained Claude Code prompts for all five are in `CONCURRENT-BUILD-ROUND-2.md`.

---

## Decision Points — Resolved This Session

| ID | Decision | Resolution |
|----|----------|-----------|
| OD-03 | Sky Points: 100 or 1,000 with $100 membership? | **1,000 coins. $1 = 10 coins.** |
| OD-10 | Public profile: directory or verification-only? | **Verification-only. No public directory.** |
| OD-15 | Sky Coins spend categories | **Five-tier catalog: record building (free), network actions, certification, credentialing, products.** |
| OD-08 | Credential expiration period | **2-year credential renewal, 3-year certification renewal.** |

**Permanent directive:** Pronouns field is permanently removed from the platform. Never reintroduce in any schema, type, form, or UI.

---

## Key Architecture Decisions (Already Made)

1. **Auth is Supabase Auth (GoTrue)** — NOT NextAuth.js
2. **Hosting is Azure Static Web Apps** — NOT Vercel
3. **No Sanity CMS** — platform owns its own data via Supabase
4. **MFA deferred to DOC-900** (now approved, in build queue)
5. **Stripe Identity deferred to Phase 5** — email verification only
6. **Pronoun fields permanently removed** (directive, commit `17c8e53`)
7. **CI is clean** — 0 lint errors, 0 warnings
8. **Sky Coins denomination** — $1 = 10 coins, $100 membership = 1,000 coins
9. **No public member directory** — verification-only model
10. **Five-tier product catalog** with earn-back model on validations/evaluations
11. **2-year credential / 3-year certification renewal cycles**

---

## What Comes After Round 2

### Round 3 candidates (requires Round 2 completion)
- **DOC-207** — Stripe Integration (requires DOC-205 coin products in DB)
- **DOC-400/401** — Validation Workflow (requires DOC-206 documents + DOC-202 expanded profile)
- **DOC-101** — Membership page copy update (requires DOC-205 pricing resolution — now resolved)

### Still open decision points
| ID | Decision | Blocks |
|----|----------|--------|
| OD-04 | Self-assessment form: universal vs. team-type-specific? | DOC-603 |
| OD-05 | Assessor report: same variants question | DOC-605, DOC-606 |
| OD-06 | Organization billing: invoicing mechanism? | DOC-613 |
| OD-07 | QRB composition: who serves, quorum? | DOC-404 |
| OD-09 | Verification portal domain: greyskyresponder.net? | DOC-502 |
| OD-11 | ATLAS hosting: which VPS? | DOC-300 |

---

## Critical Rules (Always Enforce)

- **"Service" not "career"** — always
- **Privacy is sovereign** — responder owns their data, agencies see only consented scope
- **Supabase Auth (GoTrue)** — not NextAuth.js
- **Azure Static Web Apps** — not Vercel
- **ICS/NIMS/NQS/RTLT terminology** — the platform speaks the language of the profession
- **Dashboard = command post** — ICS-structured, not consumer SaaS
- **`npm run build` must pass with zero errors** before any commit
- **Design-doc-driven** — nothing gets built without a spec
- **NO PRONOUNS FIELD** — permanently removed from the platform
